package com.eai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RfiApplicationTests {

	@Test
	void contextLoads() {
	}

}
