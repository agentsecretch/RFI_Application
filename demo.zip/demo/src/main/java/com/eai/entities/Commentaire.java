package com.eai.entities;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class Commentaire implements Serializable{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = false, unique = true)
    private Long idCommentaire;

    @Column(name = "MESSAGE", length = 4000)
    private String message;

    @ManyToOne
    @JoinColumn(name = "idRFI")
    private Rfi rfi;
    

    @Column(name="idUser",updatable = false)
    private Long createdBy;

    @Column(updatable = false)
    private LocalDateTime createdAt;

}
