package com.eai.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idUser;

    @Column(unique = true)
    private String login;

    @JsonIgnore
    private String Password;

    private String PasswordEncode;

    private String firstName;

    private String lastName;

    private String email;

    private String phoneNumber;
    
    @OneToMany(mappedBy = "initiateur")
    @JsonIgnore
    private Set<Rfi> rfi_init = new HashSet();
    
    @OneToMany(mappedBy = "destinateur")
    @JsonIgnore
    private Set<Rfi> rfi_dest = new HashSet();
}
