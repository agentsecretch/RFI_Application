package com.eai.entities;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter@Setter
public class Rfi implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idRFI;

    @Column(nullable = false)
    private String titre;

    
    private String description;


    private String response;


    @Column(nullable = false)
    private boolean isUpdatable ;
    

    @Column(updatable = false)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy="rfi")
    private Set<Commentaire> commentaire= new HashSet<>();

    @OneToMany(mappedBy="rfi")
    private Set<Document> document= new HashSet<>();
    
    @OneToMany(mappedBy="rfi")
    private Set<Historique> historique= new HashSet<>();
    
    @ManyToOne
    @JoinColumn(name = "id_initiateur")
    private User initiateur;
    
    @ManyToOne
    @JoinColumn(name = "id_detinateur")
    private User destinateur;
    

}
