package com.eai.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eai.dao.StatutRepo;
import com.eai.entities.Statut;
import com.eai.services.StatutService;

@Service
public class StatutServiceImpl implements StatutService{
	@Autowired
	StatutRepo statutRepo;
	
	@Override
	public Statut getStatus(long id) {

		return statutRepo.findById(id);
	}

	@Override
	public Statut postStatus(Statut statut) {
		return statutRepo.save(statut);
	}
	
	@Override
	public Statut changeStatus(Statut statut) {
		Statut statutOld = statutRepo.findStatut(statut.getIdRfi(),statut.getIdUser());
		statut.setIdStatut(statutOld.getIdStatut());
		Statut statutNew = statutRepo.save(statut);
		return statutNew;
	}
}
