package com.eai.services;

import java.util.List;

import com.eai.entities.Historique;
import com.eai.entities.Rfi;

public interface HistoriqueService {
	List<Historique> getHistorique(long idRFI);
	Historique posthistorique(String name, long id);
}
