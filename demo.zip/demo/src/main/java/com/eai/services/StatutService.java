package com.eai.services;

import com.eai.entities.Statut;

public interface StatutService {
	Statut getStatus(long id);
	Statut postStatus(Statut statut);
	Statut changeStatus(Statut statut);
}
