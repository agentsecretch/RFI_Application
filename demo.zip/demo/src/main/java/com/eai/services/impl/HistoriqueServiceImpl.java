package com.eai.services.impl;

import java.util.List;

import com.eai.dao.RfiRepo;
import com.eai.entities.Rfi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eai.dao.HistoriqueRepo;
import com.eai.entities.Historique;
import com.eai.services.HistoriqueService;

@Service
public class HistoriqueServiceImpl implements HistoriqueService {
	@Autowired
	HistoriqueRepo historiqueRepo;
	@Autowired
	RfiRepo rfiRepo;

	@Override
	public List<Historique> getHistorique(long idRFI) {
		
		return historiqueRepo.findByIdRFI(idRFI);
	}

	@Override
	public Historique posthistorique(String name, long id) {
		Historique historique = new Historique();
		Rfi rfi= rfiRepo.findById(id);
		historique.setUsername(name);
		historique.setRfi(rfi);

		List<Historique> historiqueList = getHistorique(rfi.getIdRFI());
		historique.setOrdre(historiqueList.size()+1);

		return historiqueRepo.save(historique);
	}

}
