package com.eai.services;

import java.util.List;

import com.eai.entities.User;

public interface UserService {
	List<User> getUsers();
	User getUser();
}
