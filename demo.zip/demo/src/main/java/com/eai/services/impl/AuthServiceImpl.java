package com.eai.services.impl;

import com.eai.dto.AuthDTO;
import com.eai.dto.AuthResponseDTO;
import com.eai.services.AuthService;
import com.eai.services.UserService;
import com.eai.utils.JwtUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthServiceImpl implements AuthService {
    private final UserService userService;
    private final BCryptPasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    public AuthServiceImpl(UserService userService,
                           BCryptPasswordEncoder passwordEncoder,
                           AuthenticationManager authenticationManager,
                           JwtUtil jwtUtil) {
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
    }
    @Override
    public AuthResponseDTO loginUser(AuthDTO authDTO) {
        try {
            // Authenticate the user
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            authDTO.getLogin(),
                            authDTO.getPassword()
                    )
            );

            // Generate JWT token
            final String token = jwtUtil.generateToken(authDTO.getLogin());

            // Return success response
            return new AuthResponseDTO(token, "success");

        } catch (BadCredentialsException e) {
            // Return error response
            return new AuthResponseDTO(null, "error: Invalid username or password.");
        }

    }
}
