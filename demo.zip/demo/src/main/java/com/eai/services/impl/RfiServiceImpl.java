package com.eai.services.impl;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.eai.config.JwtAuthFilter;
import com.eai.dao.HistoriqueRepo;
import com.eai.dao.StatutRepo;
import com.eai.entities.Historique;
import com.eai.entities.Statut;
import com.eai.entities.User;
import com.eai.services.HistoriqueService;
import com.eai.services.StatutService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eai.dao.RfiRepo;
import com.eai.dao.UserRepo;
import com.eai.entities.Rfi;
import com.eai.services.RfiService;
import com.eai.utils.ObjectMapper;


@Service
public class RfiServiceImpl implements RfiService{
	@Autowired
	UserRepo userRepo;
	@Autowired
	RfiRepo rfiRepo;
	@Autowired
	HistoriqueRepo historiqueRepo;

	@Autowired
	UserDetailsServiceImpl userDetailsService;

	@Autowired
	HistoriqueService historiqueService;


	boolean checkTitle(String titre,String login,User initiateur){
		List<List<Rfi>> rfiLists = Arrays.asList(rfiRepo.findByLoginDest(login),rfiRepo.findByLoginInit(initiateur.getLogin()));
		for(List<Rfi> rfiList : rfiLists){
			for (Rfi rfiItem : rfiList) {
				if (rfiItem.getTitre().contains(login)) {
					return true;
				}
			}
		}
		return false;
	}


	@Override
	public Rfi createRfi(Rfi rfi, String login) {
		User initiateur =userDetailsService.loadUser();
		if (rfi.getTitre()==null || rfi.getTitre().trim()=="" || checkTitle(rfi.getTitre(),login,initiateur)) throw new IllegalArgumentException("the RFI title is required.");
		Optional<Rfi> rfiOld  =rfiRepo.findByTitreAndLogin(rfi.getTitre(),login);

		if (rfiOld.isPresent())
			if	(!rfiOld.get().isUpdatable()) throw new IllegalArgumentException("An RFI with the title '" + rfiOld.get().getTitre() + "' already exists.");
			else rfi.setIdRFI(rfiOld.get().getIdRFI());
		if(login==userDetailsService.loadUser().getLogin())throw new IllegalArgumentException("the initiator can't be also the receiver.");
		User user=userRepo.findByLogin(login);
		rfi.setInitiateur(initiateur);
		rfi.setDestinateur(user);
		rfi.setCreatedAt(LocalDateTime.now());
		rfi.setUpdatable(false);
		Rfi rfiNew = rfiRepo.save(rfi);

		Historique historique = new Historique();
		historique.setRfi(rfiNew);
		historique.setUsername(user.getLogin());
		historique.setOrdre(1);
		historiqueRepo.save(historique);

		return rfiNew;
}

	@Override
	public Rfi getRfi(long idRfi) {
		Rfi rfi = rfiRepo.findById(idRfi);
		return rfi;
	}

	@Override
	public Rfi changeRfi(Rfi rfi,String login, boolean isUpdatable) {
		String titre = rfi.getTitre();
		if(titre!=null || titre.trim()=="") {
			Optional<Rfi> rfiOld = rfiRepo.findByTitreAndLogin(titre,login);

			if(rfiOld.isPresent())
				rfi.setIdRFI(rfiOld.get().getIdRFI());
			if(login==userDetailsService.loadUser().getLogin())throw new IllegalArgumentException("the initiator can't be also the receiver.");

			User user=userRepo.findByLogin(login);
			rfi.setInitiateur(userDetailsService.loadUser());
			rfi.setDestinateur(user);

			rfi.setCreatedAt(LocalDateTime.now());

			rfi.setUpdatable(isUpdatable);

			Rfi rfiNew = rfiRepo.save(rfi);
			return rfiNew;
		}else throw new IllegalArgumentException("the RFI title is required.");

	}

	@Override
	public Rfi changeDestinateur(long idRfi, String login) {
		Rfi rfi = rfiRepo.findById(idRfi);
		rfi.setDestinateur(userRepo.findByLogin(login));
		Rfi rfiNew = rfiRepo.save(rfi);
		historiqueService.posthistorique(login, idRfi);
		return rfiNew;
	}

	@Override
	public List<Rfi> getListeRfi(String login) {
		User user = userRepo.findByLogin(login);
		return rfiRepo.findByUserId(user.getIdUser());
	}

	
}
