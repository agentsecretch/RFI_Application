package com.eai.services;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.eai.entities.Document;

public interface DocumentService {
	Document saveDoc(MultipartFile file, long id) throws IOException;

	List<Document> listeDocument(long id);
	
	void deleteDoc(long idDoc);
}
