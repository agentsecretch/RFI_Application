package com.eai.services;

import java.util.List;

import com.eai.entities.Rfi;

public interface RfiService {
	Rfi createRfi(Rfi rfi, String login);
	
	Rfi getRfi(long idRfi);
	
	Rfi changeRfi(Rfi rfi,String login, boolean isUpdatable);

	Rfi changeDestinateur(long idRfi, String login);
	
	List<Rfi> getListeRfi(String login);
}
