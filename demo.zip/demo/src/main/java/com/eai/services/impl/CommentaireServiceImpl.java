package com.eai.services.impl;

import java.util.List;
import java.util.Optional;

import com.eai.dao.RfiRepo;
import com.eai.entities.Rfi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eai.dao.CommentaireRepo;
import com.eai.entities.Commentaire;
import com.eai.services.CommentaireService;


@Service
public class CommentaireServiceImpl implements CommentaireService {
	@Autowired
	CommentaireRepo commentRepo;
	@Autowired
	RfiRepo rfiRepo;

	@Override
	public Commentaire postCommentaire(Commentaire comment,long id) {
		comment.setRfi(rfiRepo.findById(id));
		Commentaire commentNew = commentRepo.save(comment);
		return commentNew;
	}

	@Override
	public List<Commentaire> getCommentaire(long id) {
		Rfi rfi = rfiRepo.findById(id);

		return commentRepo.findAllByIdRfi(rfi.getIdRFI());
	}
	

}
