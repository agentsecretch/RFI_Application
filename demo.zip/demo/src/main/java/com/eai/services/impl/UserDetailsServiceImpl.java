package com.eai.services.impl;

import com.eai.config.JwtAuthFilter;
import com.eai.dao.UserRepo;
import com.eai.entities.User;
import com.eai.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
    @Autowired
    JwtUtil jwtUtil;
    @Autowired
    UserRepo userRepo;

    // Load user by username
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userRepo.findByLogin(username);

        if(user==null) throw new UsernameNotFoundException("User not found");

        // Assign authorities based on user role
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("USER"));

        return new org.springframework.security.core.userdetails.User(user.getLogin(), user.getPasswordEncode(), authorities);
    }

    public User loadUser() {
        String username = jwtUtil.extractUsername();
        return userRepo.findByLogin(username);
    }

}
