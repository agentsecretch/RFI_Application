package com.eai.services;

import com.eai.dto.AuthDTO;
import com.eai.dto.AuthResponseDTO;

public interface AuthService {
    AuthResponseDTO loginUser(AuthDTO authDTO);
}
