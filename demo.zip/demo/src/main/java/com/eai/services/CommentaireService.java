package com.eai.services;

import java.util.List;

import com.eai.entities.Commentaire;

public interface CommentaireService {
	Commentaire postCommentaire(Commentaire comment,long id);
	List<Commentaire> getCommentaire(long id);
}
