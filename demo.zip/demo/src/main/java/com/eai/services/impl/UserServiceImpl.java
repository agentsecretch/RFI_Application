package com.eai.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eai.dao.UserRepo;
import com.eai.entities.User;
import com.eai.services.UserService;


@Service
public class UserServiceImpl implements UserService{
	@Autowired
	UserRepo userRepo;
	@Autowired
	UserDetailsServiceImpl userDetailsService;

	@Override
	public List<User> getUsers() {
		return userRepo.findAll();
	}

	@Override
	public User getUser() {

		return userDetailsService.loadUser();

	}
	
}
