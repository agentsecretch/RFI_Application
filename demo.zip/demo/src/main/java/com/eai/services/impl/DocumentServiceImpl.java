package com.eai.services.impl;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import com.eai.dao.RfiRepo;
import com.eai.entities.Rfi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.eai.dao.DocumentRepo;
import com.eai.entities.Document;
import com.eai.services.DocumentService;



@Service
public class DocumentServiceImpl implements DocumentService{
	@Autowired
	DocumentRepo docRepo;
	@Autowired
	RfiRepo rfiRepo;

	@Override
	public Document saveDoc(MultipartFile file, long id) throws IOException {
		Document document = new Document();
		document.setName(file.getOriginalFilename());
		document.setType(file.getContentType());
		document.setData(file.getBytes());
		document.setRfi(rfiRepo.findById(id));
		Document newDoc= docRepo.save(document);
		return newDoc;
	}

	@Override
	public List<Document> listeDocument(long id) {
		Rfi rfi = rfiRepo.findById(id);

		return docRepo.findByIdRFI(rfi.getIdRFI());
	}

	@Override
	public void deleteDoc(long idDoc) {
		Document doc =docRepo.findById(idDoc);
		if (doc == null) throw new IllegalArgumentException("The document don't exist.");
		docRepo.delete(doc);
	}
	

}
