package com.eai.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.entities.Historique;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface HistoriqueRepo extends JpaRepository<Historique, Long> {
	@Query("SELECT h FROM Historique h WHERE h.rfi.idRFI = :idRFI")
	List<Historique> findByIdRFI(@Param("idRFI") long idRFI);
}
