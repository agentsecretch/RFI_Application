package com.eai.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eai.entities.Statut;

public interface StatutRepo extends JpaRepository<Statut, Long> {

	@Query("SELECT s FROM Statut s " +
		       "WHERE s.idRfi= :idRfi AND s.idUser= :idUser")
	Statut findStatut(@Param("idRfi") long idRfi,@Param("idUser") long idUser);
	Statut findById(long id);

}
