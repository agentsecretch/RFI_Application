package com.eai.dao;

import com.eai.entities.Commentaire;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository

public interface CommentaireRepo extends JpaRepository<Commentaire, Long> {

	@Query("SELECT c FROM Commentaire c WHERE c.rfi.id = :idRfi")
	List<Commentaire> findAllByIdRfi(@Param("idRfi") Long idRfi);

}
