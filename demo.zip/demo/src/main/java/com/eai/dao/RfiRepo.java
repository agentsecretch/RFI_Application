package com.eai.dao;

import com.eai.entities.Rfi;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository

public interface RfiRepo extends JpaRepository<Rfi, Long> {
	@Query("SELECT r FROM Rfi r " +
		       "WHERE r.destinateur.idUser = :userId" +
		       "   OR r.initiateur.idUser = :userId")
	List<Rfi> findByUserId(@Param("userId") long userId);

	Rfi findById(long idRfi);

	@Query("SELECT r FROM Rfi r " +
			"WHERE r.titre = :titre" +
			"   AND r.destinateur.login = :login")
	Optional<Rfi> findByTitreAndLogin(@Param("titre") String titre, @Param("login") String login);

	@Query("SELECT r FROM Rfi r " +
			"WHERE r.destinateur.login = :login")
	List<Rfi> findByLoginDest(@Param("login") String login);

	@Query("SELECT r FROM Rfi r " +
			"WHERE r.initiateur.login = :login")
	List<Rfi> findByLoginInit(@Param("login") String login);

}
