package com.eai.dao;

import com.eai.entities.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface DocumentRepo extends JpaRepository<Document, Long> {

    @Query("SELECT d FROM Document d WHERE d.rfi.idRFI = :idRFI")
    List<Document> findByIdRFI(@Param("idRFI") long idRFI);

    Document findById(long idDoc);
}
