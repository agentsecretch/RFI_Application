package com.eai.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eai.entities.User;

public interface UserRepo extends JpaRepository<User, Long>{
	List<User> findAll();

	User findById(long idUser);

	User findByLogin(String login);
}
