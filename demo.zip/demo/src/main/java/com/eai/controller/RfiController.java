package com.eai.controller;


import com.eai.dto.RfiDto;
import com.eai.dto.UserDto;
import com.eai.entities.Historique;
import com.eai.entities.Rfi;
import com.eai.entities.User;
import com.eai.services.RfiService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/rfi")
public class RfiController {
    @Autowired
    RfiService rfiService;
    @Autowired
    ObjectMapper objectMapper;

    @PostMapping
    public ResponseEntity<RfiDto> createRfi(@RequestBody RfiDto rfiDto, @RequestParam String login){
        Rfi rfi =rfiService.createRfi(objectMapper.map(rfiDto , Rfi.class), login);

        return new ResponseEntity<RfiDto>(objectMapper.map(rfi,RfiDto.class),HttpStatus.CREATED);
    }
    @GetMapping
    public ResponseEntity<List<RfiDto>> listRfi(@RequestParam String login){
        List<Rfi> rfis =rfiService.getListeRfi(login);
        List<RfiDto> rfiDtos = new ArrayList<>();
        for(Rfi rfi : rfis){
            RfiDto rfiDto=objectMapper.map(rfi,RfiDto.class);
            rfiDtos.add(rfiDto);

        }
        return new ResponseEntity<List<RfiDto>>(rfiDtos, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RfiDto> getRfi(@PathVariable long id){
        Rfi rfi = rfiService.getRfi(id);
        return new ResponseEntity<RfiDto>(objectMapper.map(rfi,RfiDto.class), HttpStatus.OK);
    }

    @PutMapping("/changeRfi")
    public ResponseEntity<RfiDto> patchRfi(@RequestBody RfiDto rfiDto, @RequestParam String login){
        Rfi rfi =rfiService.changeRfi(objectMapper.map(rfiDto , Rfi.class),login,true);
        return new ResponseEntity<RfiDto>(objectMapper.map(rfi,RfiDto.class), HttpStatus.ACCEPTED);
    }


    @PutMapping("/changeDest/{id}")
    public ResponseEntity<RfiDto> changeDestinateur(@PathVariable long id, @RequestParam String login){
        Rfi rfi =rfiService.changeDestinateur(id, login);
        return new ResponseEntity<RfiDto>(objectMapper.map(rfi,RfiDto.class), HttpStatus.ACCEPTED);

    }

}
