package com.eai.controller;


import com.eai.dto.StatutDto;
import com.eai.entities.Statut;
import com.eai.services.StatutService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/statut")
public class StatutController {
    @Autowired
    StatutService statutService;
    @Autowired
    ObjectMapper objetMapper;

    @PostMapping
    public ResponseEntity<StatutDto> createStatut(@RequestBody StatutDto statutDto){
        Statut statut=statutService.postStatus(objetMapper.map(statutDto,Statut.class));

        return new ResponseEntity<StatutDto>(objetMapper.map(statut,StatutDto.class),HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<StatutDto> putStatut(@RequestBody StatutDto statutDto){
        Statut statut=statutService.changeStatus(objetMapper.map(statutDto,Statut.class));

        return new ResponseEntity<StatutDto>(objetMapper.map(statut,StatutDto.class),HttpStatus.ACCEPTED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StatutDto> getStatut(@PathVariable long id){
        Statut statut=statutService.getStatus(id);
        return new ResponseEntity<StatutDto>(objetMapper.map(statut,StatutDto.class),HttpStatus.OK);
    }
}
