package com.eai.controller;


import com.eai.dto.DocumentDto;
import com.eai.dto.UserDto;
import com.eai.entities.Document;
import com.eai.services.DocumentService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/document")
public class DocumentController {
    @Autowired
    DocumentService documentService;
    @Autowired
    ObjectMapper objectMapper;

    @GetMapping("/{id}")
    public ResponseEntity<List<DocumentDto>> getDocuments(@PathVariable long id){
        List<Document> docs =documentService.listeDocument(id);
        List<DocumentDto> docDtos = new ArrayList<>();
        for(Document doc : docs){
            DocumentDto documentDto =objectMapper.map(doc,DocumentDto.class);
            docDtos.add(documentDto);
        }
        return new ResponseEntity<List<DocumentDto>>(docDtos, HttpStatus.OK);
    }

    @PostMapping("/{id}")
    public ResponseEntity<DocumentDto> postDoc(@RequestBody MultipartFile file, @PathVariable long id) throws IOException {
        Document doc=documentService.saveDoc(file, id);

        return new ResponseEntity<DocumentDto>(objectMapper.map(doc,DocumentDto.class),HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteUser(@PathVariable long id){
        documentService.deleteDoc(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
