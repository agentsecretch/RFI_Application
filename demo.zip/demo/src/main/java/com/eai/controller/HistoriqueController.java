package com.eai.controller;


import com.eai.dto.HistoriqueDto;
import com.eai.dto.RfiDto;
import com.eai.entities.Historique;
import com.eai.entities.Rfi;
import com.eai.services.HistoriqueService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/historique")
public class HistoriqueController {
    @Autowired
    HistoriqueService historiqueService;
    @Autowired
    ObjectMapper objectMapper;

    @GetMapping
    public ResponseEntity<List<HistoriqueDto>> getUser(@RequestParam long id){
        List<Historique> historiqueList = historiqueService.getHistorique(id);
        List<HistoriqueDto> historiqueDtos = new ArrayList<>();
        for(Historique his : historiqueList){
            HistoriqueDto historiqueDto=objectMapper.map(his,HistoriqueDto.class);
            historiqueDtos.add(historiqueDto);
        }
        return new ResponseEntity<List<HistoriqueDto>>(historiqueDtos, HttpStatus.OK);
    }
}
