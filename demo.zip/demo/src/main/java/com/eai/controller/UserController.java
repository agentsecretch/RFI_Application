package com.eai.controller;


import com.eai.dto.UserDto;
import com.eai.entities.User;
import com.eai.services.UserService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    ObjectMapper objectMapper;
    @GetMapping("/users")
    public ResponseEntity<List<UserDto>> getUsers(){
        List<User> users =userService.getUsers();
        List<UserDto> userDtos = new ArrayList<>();
        for(User user : users){
            UserDto userDto=objectMapper.map(user,UserDto.class);
            userDtos.add(userDto);

        }
        return new ResponseEntity<List<UserDto>>(userDtos, HttpStatus.OK);
    }

    @GetMapping("/user")
    public ResponseEntity<UserDto> getUser(){
        User user = userService.getUser();
        return new ResponseEntity<UserDto>(objectMapper.map(user,UserDto.class), HttpStatus.OK);
    }
}
