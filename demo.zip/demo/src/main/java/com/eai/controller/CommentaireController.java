package com.eai.controller;


import com.eai.dto.CommentaireDto;
import com.eai.dto.CommentaireDto;
import com.eai.dto.StatutDto;
import com.eai.entities.Commentaire;
import com.eai.entities.Commentaire;
import com.eai.entities.Statut;
import com.eai.services.CommentaireService;
import com.eai.services.UserService;
import com.eai.utils.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/commentaire")
public class CommentaireController {
    @Autowired
    CommentaireService commentaireService;
    @Autowired
    ObjectMapper objectMapper;

    @GetMapping("/{id}")
    public ResponseEntity<List<CommentaireDto>> getUsers(@PathVariable long id){
        List<Commentaire> comments =commentaireService.getCommentaire(id);
        List<CommentaireDto> CommentaireDtos = new ArrayList<>();
        for(Commentaire comment : comments){
            CommentaireDto commentDto=objectMapper.map(comment,CommentaireDto.class);
            CommentaireDtos.add(commentDto);

        }
        return new ResponseEntity<List<CommentaireDto>>(CommentaireDtos, HttpStatus.OK);
    }
    @PostMapping("/{id}")
    public ResponseEntity<CommentaireDto> createStatut(@RequestBody CommentaireDto commentaireDto,@PathVariable long id){
        Commentaire comment =commentaireService.postCommentaire(objectMapper.map(commentaireDto,Commentaire.class),id);

        return new ResponseEntity<CommentaireDto>(objectMapper.map(comment, CommentaireDto.class),HttpStatus.CREATED);
    }
}
