package com.eai;

import com.eai.dao.UserRepo;
import com.eai.entities.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.stream.Stream;

@SpringBootApplication
public class RfiApplication {
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	public static void main(String[] args) {
		SpringApplication.run(RfiApplication.class, args);
	}

	@Bean
	CommandLineRunner commandLineRunner(UserRepo userRepo) {
		return args -> {
			Stream.of("Hassan", "Imane", "Mohamed", "Nouha", "Jihane", "Jilali").forEach(name -> {
				User user = new User();
				user.setFirstName(name);
				user.setLastName(name);
				user.setLogin(name+"_login");
				user.setEmail(name + "@gmail.com");
				user.setPhoneNumber("0645176270");
				user.setPassword(name + "_password");
				user.setPasswordEncode(passwordEncoder.encode(name + "_password"));
				userRepo.save(user);
			});

		};
	}
}
