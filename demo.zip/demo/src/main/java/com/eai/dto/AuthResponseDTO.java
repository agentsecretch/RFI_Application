package com.eai.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter@Setter@AllArgsConstructor
public class AuthResponseDTO implements Serializable {
    private static final long serialVersionUID = 6212969613L;

    private String token;
    private String message;
}
