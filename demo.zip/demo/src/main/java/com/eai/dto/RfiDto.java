package com.eai.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.eai.entities.User;
import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class RfiDto implements Serializable {
    private static final long serialVersionUID = 6212969613L;

    private long idRFI;
	
	private String titre;

    
    private String description;

    private String response;

    private LocalDateTime createdAt;

    private UserDto destinateur;

    private UserDto initiateur;
}
