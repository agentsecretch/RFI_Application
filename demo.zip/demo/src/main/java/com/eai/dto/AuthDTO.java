package com.eai.dto;


import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter@Setter
public class AuthDTO implements Serializable {
    private static final long serialVersionUID = 6212969613L;

    private String login;

    private String password;
}
