package com.eai.dto;


import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class UserDto implements Serializable {
    private static final long serialVersionUID = 6212969613L;


    private long idUser;
    private String login;

    private String firstName;

    private String lastName;

    private String email;

    private String phoneNumber;
}
