package com.eai.dto;


import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter@Setter
public class DocumentDto {
    private long idDocument;

    private String type;

    private String name;


    private byte[] data;

    private RfiDto rfi;

    private LocalDateTime createdAt;

    private long createdBy;

}
